<?php

namespace App\Repositories;

use App\Models\Employees;
use App\Models\References;

class EmployeesRepository
{
    protected $employees;

    public function __construct(Employees $employees)
    {
        $this->employees = $employees;
    }

    public function getPaginate($params)
    {
        $params['per_page'] = $params['per_page'] ? $params['per_page'] : 10;
        $params['page'] = $params['page'] ? $params['page'] : 1;

        $employees = $this->employee->orderBy($params['order_by'], $params['order_type']);

        $employees = $employees->paginate($params['per_page']);

        foreach($employees as $employee){
            $status = References::select('name')->where('id', $employee['status_id'])->first();
            $employee['status'] = $status;
        }

        return $employees;
    }

    public function store($data)
    {
        $employees = Employees::create([
            'name' => $data['name'],
            'status_id' => $data['status_id'],
            'salary' => $data['salary'],
        ]);

        return $employees;
    }
}
