<?php

namespace App\Repositories;

use App\Models\Employees;
use App\Models\Overtimes;
use App\Models\References;
use App\Models\Settings;

class OvertimesRepository
{
    protected $overtime;

    public function __construct(Overtimes $overtime)
    {
        $this->overtime = $overtime;
    }

    public function store($data)
    {
        $overtimes = Overtimes::create([
            'employee_id' => $data['employee_id'],
            'date' => $data['date'],
            'time_started' => $data['time_started'],
            'time_ended' => $data['time_ended']
        ]);

        return $overtimes;
    }

    public function showByRange($data)
    {
        $overtimes = Overtimes::whereBetween('date', [$data['date_started'], $data['date_ended']])
            ->orderBy('date')->get();

        foreach ($overtimes as $overtime) {
            $employee = Employees::select('name')->where('id', $overtime['employee_id'])->first();
            $overtime['employee'] = $employee;
        }

        return $overtimes;
    }

    public function calculatePays($data)
    {
        $employees = Employees::all();

        foreach ($employees as $employee) {
            $status = References::select('name')->where('id', $employee['id'])->first();
            $employee['status'] = $status;

            $overtimes = Overtimes::where('employee_id', $employee->id)->where('date', 'like', $data['month'] . '%')
                ->select(['id', 'date', 'time_started', 'time_ended'])->get();

            $duration_total = 0;
            foreach ($overtimes as $overtime) {
                $duration = ((strtotime($overtime['time_ended']) - strtotime($overtime['time_started'])) / 3600);
                if ($employee['status']->name === true) {
                    $duration = $duration - 1;
                    if ($duration < 0)
                        $duration = 0;
                }
                $duration = round($duration);
                $overtime['overtime_duration'] = $duration;
                $duration_total += $duration;
            }
            $employee['overtimes'] = $overtimes;
            $employee['overtime_duration_total'] = $duration_total;
            $salary = $employee['salary'];
            $amount = 0;

            $overtime_method = Settings::select('expression')->where('key', 'overtime_method')->first();
            $expression = $overtime_method->expression;
            $expression = str_replace('salary', $salary, $expression);
            $expression = str_replace('overtime_duration_total', $duration_total, $expression);

            eval('$employee["amount"] = ' . $expression . ';');

        }

        return $employees;
    }
}
