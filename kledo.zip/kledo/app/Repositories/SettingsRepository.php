<?php

namespace App\Repositories;

use App\Models\References;
use App\Models\Settings;

class SettingsRepository{

    protected $setting;

    public function __construct(Settings $setting)
    {
        $this->setting = $setting;
    }

    public function changeMethod($data){
        $expression = References::find($data['value']);
        $setting = Settings::where('id', 1)->update([
            'key' => $data['key'],
            'value' => $data['value'],
            'expression' => $expression['expression']
        ]);
    }
}
