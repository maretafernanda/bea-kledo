<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class References extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $fillable = [
        'id', 'code', 'name', 'expression'
    ];

    public function setting()
    {
        return $this->hasOne(Settings::class, 'value');
    }
}
