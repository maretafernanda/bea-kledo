<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Employees extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $fillable = [
        'id', 'name', 'salary'
    ];

    public function overtime(){
        return $this->hasMany(Overtimes::class, 'employee_id');
    }

    public function reference(){
        return $this->belongsTo(References::class, 'id');
    }

    public function OvertimeDuration(){
        $duration = Overtimes::where('employee_id', $this->id)->get();
        $result = 0;
        foreach ($duration as $item) {
            $result += $item->overtime_duration;
        }
        return $result;
    }

    public function OvertimeMethod($value)
    {
        switch ($this->references->id) {
            case 1:
                $result = ($this->salary / 173) * $this->OvertimeDuration();
                break;

            case 2:
                $result = 10000 * $this->OvertimeDuration();
                break;
        }
        
        return $result;
    }
}
