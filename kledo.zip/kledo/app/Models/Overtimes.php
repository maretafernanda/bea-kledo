<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Overtimes extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $fillable = [
        'id', 'employee_id', 'date', 'time_started', 'time_ended'
    ];

    public function employee(){
        return $this->belongsTo(Employees::class, 'employee_id');
    }

    public function OvertimeDuration($value){
        $time_start=strtotime($this->date.' '.$this->time_started);
        $time_end=strtotime($this->date.' '.$this->time_ended);
        $difference=$time_end - $time_start;
        $hour = floor($difference/(60*60));
        return number_format($hour,0,",",".")-1;
    }
}
